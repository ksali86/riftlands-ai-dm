# Riftlands AI DM v1.4.1 — Two-Phase Sync + Recap
- Clears all commands globally and per guild
- Waits 5 seconds for Discord to propagate
- Force-syncs commands afterwards
- Adds `/recap` command for scene summaries
